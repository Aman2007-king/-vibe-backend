// ============================================================
//  VIBE SOCIAL — UPLOAD MIDDLEWARE (Multer + Sharp)
// ============================================================
const multer = require('multer');
const sharp  = require('sharp');
const path   = require('path');
const fs     = require('fs');
const { v4: uuid } = require('uuid');

const UPLOAD_DIR = process.env.UPLOAD_PATH || path.join(__dirname, '../../uploads');

// Ensure upload dirs exist
['avatars','posts','stories','reels','thumbnails','messages'].forEach(dir => {
  const p = path.join(UPLOAD_DIR, dir);
  if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
});

// ── Storage: disk ─────────────────────────────────────────────
const storage = multer.memoryStorage(); // process in memory first

// ── File filter ───────────────────────────────────────────────
const fileFilter = (req, file, cb) => {
  const allowed = /jpeg|jpg|png|gif|webp|mp4|mov|avi|webm|mkv|heic/;
  const ext = path.extname(file.originalname).toLowerCase().replace('.', '');
  if (allowed.test(ext) || allowed.test(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error(`File type '${ext}' not supported. Use JPEG, PNG, GIF, WebP, MP4, MOV, WebM.`));
  }
};

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: parseInt(process.env.MAX_FILE_SIZE) || 50 * 1024 * 1024 },
});

// ── Image processor ───────────────────────────────────────────
const processImage = async (buffer, options = {}) => {
  const { width = 1080, height, quality = 85, format = 'jpeg', fit = 'inside' } = options;
  let pipeline = sharp(buffer).rotate(); // auto-rotate from EXIF
  if (width || height) {
    pipeline = pipeline.resize(width, height, { fit, withoutEnlargement: true });
  }
  if (format === 'jpeg') pipeline = pipeline.jpeg({ quality, progressive: true });
  else if (format === 'png') pipeline = pipeline.png({ quality });
  else if (format === 'webp') pipeline = pipeline.webp({ quality });
  return pipeline.toBuffer();
};

// ── Middleware: post media ─────────────────────────────────────
const handlePostUpload = async (req, res, next) => {
  if (!req.files && !req.file) return next();
  try {
    const files = req.files || (req.file ? [req.file] : []);
    const processed = [];
    for (const file of files) {
      const isVideo = file.mimetype.startsWith('video/');
      const filename = `${uuid()}.${isVideo ? 'mp4' : 'jpg'}`;
      const filepath = path.join(UPLOAD_DIR, 'posts', filename);

      if (isVideo) {
        fs.writeFileSync(filepath, file.buffer);
        processed.push({ url: filename, type: 'video', size: file.size });
      } else {
        const processed_buf = await processImage(file.buffer, { width: 1080, quality: 85 });
        fs.writeFileSync(filepath, processed_buf);
        // Generate thumbnail
        const thumbName = `thumb_${filename}`;
        const thumbBuf = await processImage(file.buffer, { width: 320, height: 320, fit: 'cover', quality: 70 });
        fs.writeFileSync(path.join(UPLOAD_DIR, 'thumbnails', thumbName), thumbBuf);
        // Get dimensions
        const meta = await sharp(processed_buf).metadata();
        processed.push({ url: filename, type: 'image', width: meta.width, height: meta.height, size: processed_buf.length, thumbnail: thumbName });
      }
    }
    req.processedMedia = processed;
    next();
  } catch (err) { next(err); }
};

// ── Middleware: avatar ────────────────────────────────────────
const handleAvatarUpload = async (req, res, next) => {
  if (!req.file) return next();
  try {
    const filename = `${uuid()}.jpg`;
    const filepath = path.join(UPLOAD_DIR, 'avatars', filename);
    const buf = await processImage(req.file.buffer, { width: 400, height: 400, fit: 'cover', quality: 90 });
    fs.writeFileSync(filepath, buf);
    req.avatarFilename = filename;
    next();
  } catch (err) { next(err); }
};

// ── Middleware: story ─────────────────────────────────────────
const handleStoryUpload = async (req, res, next) => {
  if (!req.file) return next();
  try {
    const isVideo = req.file.mimetype.startsWith('video/');
    const filename = `${uuid()}.${isVideo ? 'mp4' : 'jpg'}`;
    const filepath = path.join(UPLOAD_DIR, 'stories', filename);
    if (isVideo) {
      fs.writeFileSync(filepath, req.file.buffer);
    } else {
      const buf = await processImage(req.file.buffer, { width: 1080, height: 1920, fit: 'contain', quality: 85 });
      fs.writeFileSync(filepath, buf);
    }
    req.storyFilename = filename;
    req.storyIsVideo  = isVideo;
    next();
  } catch (err) { next(err); }
};

module.exports = { upload, handlePostUpload, handleAvatarUpload, handleStoryUpload };
