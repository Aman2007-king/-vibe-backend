// ============================================================
//  VIBE SOCIAL — USER MODEL
// ============================================================
const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');

const userSchema = new mongoose.Schema({
  username: {
    type: String, required: true, unique: true, trim: true,
    minlength: 3, maxlength: 30,
    match: [/^[a-zA-Z0-9._]+$/, 'Username can only contain letters, numbers, dots and underscores'],
    lowercase: true,
  },
  email: {
    type: String, required: true, unique: true, trim: true, lowercase: true,
    match: [/^\S+@\S+\.\S+$/, 'Please enter a valid email'],
  },
  password: { type: String, required: true, minlength: 6, select: false },
  phone:    { type: String, trim: true },

  // Profile
  fullName:  { type: String, required: true, trim: true, maxlength: 60 },
  bio:       { type: String, maxlength: 150, default: '' },
  website:   { type: String, maxlength: 100 },
  avatar:    { type: String, default: '' },
  coverPhoto:{ type: String, default: '' },
  gender:    { type: String, enum: ['male','female','other','prefer_not_to_say'] },
  birthDate: { type: Date },
  location:  { type: String, maxlength: 60 },

  // Verification
  verified:  { type: Boolean, default: false },
  verifiedAt:{ type: Date },

  // Social graph
  followers:       [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  following:       [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  followersCount:  { type: Number, default: 0 },
  followingCount:  { type: Number, default: 0 },
  blockedUsers:    [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  closeFriends:    [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],

  // Content counts (denormalized for speed)
  postsCount:  { type: Number, default: 0 },
  reelsCount:  { type: Number, default: 0 },
  storiesCount:{ type: Number, default: 0 },

  // Account type
  accountType: { type: String, enum: ['personal','creator','business'], default: 'personal' },
  isPrivate:   { type: Boolean, default: false },
  isActive:    { type: Boolean, default: true },

  // Saved posts
  savedPosts: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Post' }],

  // Settings
  settings: {
    notifications: {
      likes:     { type: Boolean, default: true },
      comments:  { type: Boolean, default: true },
      follows:   { type: Boolean, default: true },
      messages:  { type: Boolean, default: true },
      livevideo: { type: Boolean, default: true },
    },
    privacy: {
      showActivity:    { type: Boolean, default: true },
      allowTagging:    { type: Boolean, default: true },
      allowMentions:   { type: Boolean, default: true },
    },
  },

  // Auth
  refreshToken: { type: String, select: false },
  resetPasswordToken:   { type: String, select: false },
  resetPasswordExpires: { type: Date,   select: false },

  // Activity
  lastSeen:  { type: Date, default: Date.now },
  createdAt: { type: Date, default: Date.now },
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true },
});

// ── Indexes ───────────────────────────────────────────────────
userSchema.index({ username: 1 });
userSchema.index({ email: 1 });
userSchema.index({ fullName: 'text', username: 'text', bio: 'text' });
userSchema.index({ followers: 1 });
userSchema.index({ following: 1 });

// ── Virtuals ─────────────────────────────────────────────────
userSchema.virtual('avatarUrl').get(function () {
  if (!this.avatar) return `https://ui-avatars.com/api/?name=${encodeURIComponent(this.fullName)}&background=random`;
  if (this.avatar.startsWith('http')) return this.avatar;
  return `${process.env.SERVER_URL || 'http://localhost:5000'}/uploads/avatars/${this.avatar}`;
});

// ── Pre-save: hash password ───────────────────────────────────
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

// ── Methods ───────────────────────────────────────────────────
userSchema.methods.comparePassword = async function (candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

userSchema.methods.isFollowing = function (userId) {
  return this.following.some(id => id.toString() === userId.toString());
};

userSchema.methods.isFollowedBy = function (userId) {
  return this.followers.some(id => id.toString() === userId.toString());
};

userSchema.methods.isBlocked = function (userId) {
  return this.blockedUsers.some(id => id.toString() === userId.toString());
};

userSchema.methods.toPublicJSON = function (currentUserId) {
  return {
    id: this._id,
    username: this.username,
    fullName: this.fullName,
    bio: this.bio,
    website: this.website,
    avatar: this.avatarUrl,
    coverPhoto: this.coverPhoto,
    verified: this.verified,
    isPrivate: this.isPrivate,
    accountType: this.accountType,
    followersCount: this.followersCount,
    followingCount: this.followingCount,
    postsCount: this.postsCount,
    reelsCount: this.reelsCount,
    location: this.location,
    lastSeen: this.lastSeen,
    createdAt: this.createdAt,
    isFollowing: currentUserId ? this.isFollowedBy(currentUserId) : false,
    isFollowedBy: currentUserId ? this.isFollowing(currentUserId) : false,
  };
};

module.exports = mongoose.model('User', userSchema);
