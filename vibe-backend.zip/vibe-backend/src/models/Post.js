// ============================================================
//  VIBE SOCIAL — POST MODEL
// ============================================================
const mongoose = require('mongoose');

const mediaSchema = new mongoose.Schema({
  url:       { type: String, required: true },
  type:      { type: String, enum: ['image','video'], required: true },
  width:     Number, height: Number,
  duration:  Number, // seconds for video
  thumbnail: String, // video thumbnail
  altText:   String,
  size:      Number, // bytes
}, { _id: false });

const postSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },

  // Content
  type:    { type: String, enum: ['post','reel','story','carousel'], default: 'post' },
  media:   [mediaSchema],  // supports multiple images (carousel)
  caption: { type: String, maxlength: 2200, default: '' },
  location:{ type: String, maxlength: 100 },
  tags:    [{ type: String }],           // #hashtags
  mentions:[{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }], // @mentions
  altText: { type: String, maxlength: 150 },

  // Music / Audio (reels)
  audio: {
    title:  String,
    artist: String,
    url:    String,
    cover:  String,
  },

  // Engagement
  likes:        [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  likesCount:   { type: Number, default: 0 },
  commentsCount:{ type: Number, default: 0 },
  sharesCount:  { type: Number, default: 0 },
  savesCount:   { type: Number, default: 0 },
  viewsCount:   { type: Number, default: 0 },  // for reels/videos

  // Reel-specific
  reelDuration: Number,
  reelAudio:    String,
  shares:       [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],

  // Story-specific
  expiresAt:  Date,  // stories expire after 24h
  viewers:    [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  viewersCount: { type: Number, default: 0 },

  // Settings
  commentsDisabled: { type: Boolean, default: false },
  likesHidden:      { type: Boolean, default: false },
  isArchived:       { type: Boolean, default: false },
  isDeleted:        { type: Boolean, default: false },

  // Feed ranking signals
  engagementScore: { type: Number, default: 0 },
  reachScore:      { type: Number, default: 0 },

  createdAt: { type: Date, default: Date.now },
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true },
});

// ── Indexes ───────────────────────────────────────────────────
postSchema.index({ user: 1, createdAt: -1 });
postSchema.index({ type: 1, createdAt: -1 });
postSchema.index({ tags: 1 });
postSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 }); // auto-delete stories
postSchema.index({ caption: 'text', tags: 'text' });
postSchema.index({ engagementScore: -1 });
postSchema.index({ isDeleted: 1, createdAt: -1 });

// ── Virtuals ─────────────────────────────────────────────────
postSchema.virtual('mediaUrls').get(function () {
  return (this.media || []).map(m => ({
    ...m,
    url: m.url.startsWith('http') ? m.url
      : `${process.env.SERVER_URL || 'http://localhost:5000'}/uploads/posts/${m.url}`,
    thumbnail: m.thumbnail
      ? (m.thumbnail.startsWith('http') ? m.thumbnail
          : `${process.env.SERVER_URL || 'http://localhost:5000'}/uploads/posts/${m.thumbnail}`)
      : null,
  }));
});

// ── Pre-save: update engagement score ────────────────────────
postSchema.pre('save', function (next) {
  // Simple engagement score: likes×1 + comments×3 + shares×2 + saves×2
  this.engagementScore =
    (this.likesCount * 1) +
    (this.commentsCount * 3) +
    (this.sharesCount * 2) +
    (this.savesCount * 2);
  next();
});

// ── Methods ───────────────────────────────────────────────────
postSchema.methods.isLikedBy = function (userId) {
  return this.likes.some(id => id.toString() === userId.toString());
};

module.exports = mongoose.model('Post', postSchema);
