module.exports = require('./allRoutes').groupsRoutes;
