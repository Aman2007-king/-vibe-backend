module.exports = require('./allRoutes').storiesRoutes;
