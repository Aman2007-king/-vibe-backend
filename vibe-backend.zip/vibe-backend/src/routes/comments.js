module.exports = require('./allRoutes').commentsRoutes;
