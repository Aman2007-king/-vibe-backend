module.exports = require('./allRoutes').messagesRoutes;
