// ============================================================
//  VIBE SOCIAL — AUTH ROUTES
//  POST /api/auth/register
//  POST /api/auth/login
//  POST /api/auth/logout
//  GET  /api/auth/me
//  POST /api/auth/refresh
//  POST /api/auth/forgot-password
//  POST /api/auth/reset-password/:token
// ============================================================
const router  = require('express').Router();
const { body, validationResult } = require('express-validator');
const User    = require('../models/User');
const { protect, generateToken } = require('../middleware/auth');
const { upload, handleAvatarUpload } = require('../middleware/upload');

const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ success: false, errors: errors.array() });
  }
  next();
};

// ── REGISTER ──────────────────────────────────────────────────
router.post('/register',
  upload.single('avatar'),
  handleAvatarUpload,
  [
    body('username').trim().isLength({ min: 3, max: 30 }).matches(/^[a-zA-Z0-9._]+$/),
    body('email').isEmail().normalizeEmail(),
    body('password').isLength({ min: 6 }),
    body('fullName').trim().isLength({ min: 1, max: 60 }),
  ],
  validate,
  async (req, res) => {
    try {
      const { username, email, password, fullName, phone } = req.body;

      // Check uniqueness
      const [existingUser, existingEmail] = await Promise.all([
        User.findOne({ username: username.toLowerCase() }),
        User.findOne({ email: email.toLowerCase() }),
      ]);
      if (existingUser) return res.status(409).json({ success: false, message: 'Username already taken.' });
      if (existingEmail) return res.status(409).json({ success: false, message: 'Email already registered.' });

      const user = await User.create({
        username:  username.toLowerCase(),
        email:     email.toLowerCase(),
        password,
        fullName,
        phone,
        avatar:    req.avatarFilename || '',
      });

      const token = generateToken(user._id);
      res.status(201).json({
        success: true,
        message: 'Account created successfully!',
        token,
        user: {
          id: user._id, username: user.username, fullName: user.fullName,
          email: user.email, avatar: user.avatarUrl,
          verified: user.verified, accountType: user.accountType,
        },
      });
    } catch (err) {
      console.error('Register error:', err);
      res.status(500).json({ success: false, message: 'Registration failed. Please try again.' });
    }
  }
);

// ── LOGIN ─────────────────────────────────────────────────────
router.post('/login',
  [
    body('identifier').trim().notEmpty().withMessage('Username or email is required'),
    body('password').notEmpty().withMessage('Password is required'),
  ],
  validate,
  async (req, res) => {
    try {
      const { identifier, password } = req.body;
      const isEmail = identifier.includes('@');

      const user = await User.findOne(
        isEmail ? { email: identifier.toLowerCase() } : { username: identifier.toLowerCase() }
      ).select('+password');

      if (!user || !(await user.comparePassword(password))) {
        return res.status(401).json({ success: false, message: 'Incorrect username or password.' });
      }
      if (!user.isActive) {
        return res.status(403).json({ success: false, message: 'Your account has been deactivated.' });
      }

      user.lastSeen = new Date();
      await user.save({ validateBeforeSave: false });

      const token = generateToken(user._id);
      res.json({
        success: true,
        message: 'Login successful!',
        token,
        user: {
          id: user._id, username: user.username, fullName: user.fullName,
          email: user.email, avatar: user.avatarUrl,
          verified: user.verified, accountType: user.accountType,
          bio: user.bio, website: user.website,
          followersCount: user.followersCount, followingCount: user.followingCount,
          postsCount: user.postsCount,
        },
      });
    } catch (err) {
      console.error('Login error:', err);
      res.status(500).json({ success: false, message: 'Login failed. Please try again.' });
    }
  }
);

// ── GET ME ────────────────────────────────────────────────────
router.get('/me', protect, async (req, res) => {
  const user = await User.findById(req.user._id)
    .populate('following', 'username avatar verified')
    .populate('followers', 'username avatar verified');
  res.json({ success: true, user: user.toPublicJSON() });
});

// ── LOGOUT ───────────────────────────────────────────────────
router.post('/logout', protect, async (req, res) => {
  await User.findByIdAndUpdate(req.user._id, { lastSeen: new Date() });
  res.json({ success: true, message: 'Logged out successfully.' });
});

// ── CHECK USERNAME AVAILABILITY ───────────────────────────────
router.get('/check-username/:username', async (req, res) => {
  const exists = await User.findOne({ username: req.params.username.toLowerCase() });
  res.json({ success: true, available: !exists });
});

module.exports = router;
