module.exports = require('./allRoutes').usersRoutes;
