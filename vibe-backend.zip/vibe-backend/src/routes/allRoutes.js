// ============================================================
//  VIBE SOCIAL — ALL REMAINING ROUTES
// ============================================================
const router_users   = require('express').Router();
const router_comments= require('express').Router();
const router_messages= require('express').Router();
const router_stories = require('express').Router();
const router_notifs  = require('express').Router();
const router_search  = require('express').Router();
const router_groups  = require('express').Router();
const router_explore = require('express').Router();
const router_reels   = require('express').Router();

const User   = require('../models/User');
const Post   = require('../models/Post');
const { Comment, Conversation, Message, Notification, Group, Story } = require('../models/index');
const { protect, optionalAuth } = require('../middleware/auth');
const { upload, handlePostUpload, handleAvatarUpload, handleStoryUpload } = require('../middleware/upload');
const { isUserOnline } = require('../socket/socketManager');

// ═══════════════════════════════════════════════════════════════
//  USERS
// ═══════════════════════════════════════════════════════════════

// GET /api/users/:username — get profile
router_users.get('/:username', optionalAuth, async (req, res) => {
  try {
    const user = await User.findOne({ username: req.params.username.toLowerCase() });
    if (!user) return res.status(404).json({ success: false, message: 'User not found.' });
    const pub = user.toPublicJSON(req.user?._id);
    pub.isOnline = isUserOnline(user._id);
    res.json({ success: true, user: pub });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// PUT /api/users/me — update profile
router_users.put('/me', protect,
  upload.fields([{ name: 'avatar', maxCount: 1 }, { name: 'cover', maxCount: 1 }]),
  async (req, res) => {
    try {
      const allowed = ['fullName','bio','website','gender','birthDate','location','isPrivate','accountType'];
      const updates = {};
      allowed.forEach(f => { if (req.body[f] !== undefined) updates[f] = req.body[f]; });
      if (req.files?.avatar?.[0]) {
        const { handleAvatarUpload: hau } = require('../middleware/upload');
        req.file = req.files.avatar[0];
        await new Promise((res, rej) => hau(req, {}, (e) => e ? rej(e) : res()));
        if (req.avatarFilename) updates.avatar = req.avatarFilename;
      }
      const user = await User.findByIdAndUpdate(req.user._id, updates, { new: true, runValidators: true });
      // Sync in localStorage for current session
      const cu = JSON.parse(JSON.stringify(user));
      cu.avatar = user.avatarUrl;
      res.json({ success: true, user: cu });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
  }
);

// POST /api/users/:id/follow
router_users.post('/:id/follow', protect, async (req, res) => {
  try {
    if (req.params.id === req.user._id.toString()) {
      return res.status(400).json({ success: false, message: "Can't follow yourself." });
    }
    const [target, me] = await Promise.all([
      User.findById(req.params.id),
      User.findById(req.user._id),
    ]);
    if (!target) return res.status(404).json({ success: false, message: 'User not found.' });
    const already = me.following.some(id => id.toString() === target._id.toString());
    if (already) {
      me.following.pull(target._id);
      target.followers.pull(me._id);
      me.followingCount = Math.max(0, me.followingCount - 1);
      target.followersCount = Math.max(0, target.followersCount - 1);
    } else {
      me.following.push(target._id);
      target.followers.push(me._id);
      me.followingCount += 1;
      target.followersCount += 1;
      // Notify
      const notif = await Notification.create({ recipient: target._id, sender: me._id, type: 'follow', message: `${me.username} started following you` });
      const pop = await notif.populate('sender', 'username avatar verified');
      req.app.get('io').to(`user:${target._id}`).emit('notification', pop);
      req.app.get('io').to(`user:${target._id}`).emit('new_follower', { from: { id: me._id, username: me.username, avatar: me.avatarUrl } });
    }
    await Promise.all([me.save({ validateBeforeSave: false }), target.save({ validateBeforeSave: false })]);
    res.json({ success: true, following: !already, followersCount: target.followersCount });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// GET /api/users/:id/followers
router_users.get('/:id/followers', optionalAuth, async (req, res) => {
  try {
    const user = await User.findById(req.params.id).populate('followers', 'username fullName avatar verified bio followersCount');
    if (!user) return res.status(404).json({ success: false, message: 'User not found.' });
    const list = user.followers.map(u => ({ ...u.toObject(), isOnline: isUserOnline(u._id), avatar: u.avatarUrl }));
    res.json({ success: true, followers: list });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// GET /api/users/:id/following
router_users.get('/:id/following', optionalAuth, async (req, res) => {
  try {
    const user = await User.findById(req.params.id).populate('following', 'username fullName avatar verified bio followersCount');
    if (!user) return res.status(404).json({ success: false, message: 'User not found.' });
    const list = user.following.map(u => ({ ...u.toObject(), isOnline: isUserOnline(u._id), avatar: u.avatarUrl }));
    res.json({ success: true, following: list });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// GET /api/users/:id/suggestions
router_users.get('/:id/suggestions', protect, async (req, res) => {
  try {
    const me = await User.findById(req.user._id).select('following');
    const exclude = [...(me.following || []), req.user._id];
    const suggestions = await User.find({ _id: { $nin: exclude }, isActive: true })
      .select('username fullName avatar verified bio followersCount')
      .sort({ followersCount: -1 }).limit(10);
    res.json({ success: true, suggestions: suggestions.map(u => ({ ...u.toObject(), avatar: u.avatarUrl })) });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ═══════════════════════════════════════════════════════════════
//  COMMENTS
// ═══════════════════════════════════════════════════════════════

// GET /api/comments/:postId
router_comments.get('/:postId', optionalAuth, async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const comments = await Comment.find({ post: req.params.postId, parent: null, isDeleted: false })
      .populate('user', 'username avatar verified')
      .sort({ createdAt: -1 }).skip((page-1)*limit).limit(+limit);
    res.json({ success: true, comments });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// POST /api/comments/:postId
router_comments.post('/:postId', protect, async (req, res) => {
  try {
    const { text, parentId } = req.body;
    if (!text?.trim()) return res.status(400).json({ success: false, message: 'Comment text required.' });
    const post = await Post.findById(req.params.postId).select('user commentsDisabled');
    if (!post) return res.status(404).json({ success: false, message: 'Post not found.' });
    if (post.commentsDisabled) return res.status(403).json({ success: false, message: 'Comments are disabled.' });

    const comment = await Comment.create({ post: post._id, user: req.user._id, text: text.trim(), parent: parentId || null });
    await Post.findByIdAndUpdate(post._id, { $inc: { commentsCount: 1 } });
    if (parentId) await Comment.findByIdAndUpdate(parentId, { $push: { replies: comment._id }, $inc: { repliesCount: 1 } });

    const populated = await comment.populate('user', 'username avatar verified');
    req.app.get('io').emit('comment_added', { postId: post._id, comment: populated });

    // Notify
    if (post.user.toString() !== req.user._id.toString()) {
      const notif = await Notification.create({ recipient: post.user, sender: req.user._id, type: 'comment', post: post._id, message: `${req.user.username} commented: "${text.slice(0,40)}"` });
      const pop = await notif.populate('sender', 'username avatar');
      req.app.get('io').to(`user:${post.user}`).emit('notification', pop);
    }
    res.status(201).json({ success: true, comment: populated });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// POST /api/comments/:id/like
router_comments.post('/:id/like', protect, async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);
    if (!comment) return res.status(404).json({ success: false, message: 'Comment not found.' });
    const liked = comment.likes.some(id => id.toString() === req.user._id.toString());
    if (liked) { comment.likes.pull(req.user._id); comment.likesCount--; }
    else { comment.likes.push(req.user._id); comment.likesCount++; }
    await comment.save();
    res.json({ success: true, liked: !liked, likesCount: comment.likesCount });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// DELETE /api/comments/:id
router_comments.delete('/:id', protect, async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);
    if (!comment) return res.status(404).json({ success: false, message: 'Comment not found.' });
    if (comment.user.toString() !== req.user._id.toString()) return res.status(403).json({ success: false, message: 'Not authorized.' });
    comment.isDeleted = true;
    await comment.save();
    await Post.findByIdAndUpdate(comment.post, { $inc: { commentsCount: -1 } });
    req.app.get('io').emit('comment_deleted', { postId: comment.post, commentId: comment._id });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ═══════════════════════════════════════════════════════════════
//  MESSAGES / CONVERSATIONS
// ═══════════════════════════════════════════════════════════════

// GET /api/messages/conversations
router_messages.get('/conversations', protect, async (req, res) => {
  try {
    const convs = await Conversation.find({ participants: req.user._id, deletedFor: { $ne: req.user._id } })
      .populate('participants', 'username fullName avatar verified')
      .sort({ 'lastMessage.ts': -1 });
    const result = convs.map(c => {
      const other = c.participants.find(p => p._id.toString() !== req.user._id.toString());
      return {
        id: c._id, isGroup: c.isGroup, groupName: c.groupName, groupAvatar: c.groupAvatar,
        partner: other ? { ...other.toObject(), avatar: other.avatarUrl, isOnline: isUserOnline(other._id) } : null,
        lastMessage: c.lastMessage,
        unreadCount: c.unreadCounts?.get(req.user._id.toString()) || 0,
      };
    });
    res.json({ success: true, conversations: result });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// POST /api/messages/conversations — start or get conversation
router_messages.post('/conversations', protect, async (req, res) => {
  try {
    const { userId } = req.body;
    let conv = await Conversation.findOne({ participants: { $all: [req.user._id, userId], $size: 2 }, isGroup: false });
    if (!conv) conv = await Conversation.create({ participants: [req.user._id, userId] });
    await conv.populate('participants', 'username fullName avatar verified');
    res.json({ success: true, conversation: conv });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// GET /api/messages/:conversationId
router_messages.get('/:conversationId', protect, async (req, res) => {
  try {
    const { page = 1, limit = 30 } = req.query;
    const msgs = await Message.find({ conversation: req.params.conversationId, deletedFor: { $ne: req.user._id }, isDeleted: false })
      .populate('sender', 'username avatar verified')
      .sort({ createdAt: -1 }).skip((page-1)*limit).limit(+limit);
    // Mark as read
    await Conversation.findByIdAndUpdate(req.params.conversationId, { $set: { [`unreadCounts.${req.user._id}`]: 0 } });
    res.json({ success: true, messages: msgs.reverse(), page: +page });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// POST /api/messages/:conversationId — send message
router_messages.post('/:conversationId',
  protect,
  upload.single('media'),
  handlePostUpload,
  async (req, res) => {
    try {
      const { text, type = 'text', replyTo, sharedPost } = req.body;
      const conv = await Conversation.findById(req.params.conversationId);
      if (!conv) return res.status(404).json({ success: false, message: 'Conversation not found.' });
      if (!conv.participants.some(p => p.toString() === req.user._id.toString())) {
        return res.status(403).json({ success: false, message: 'Not a participant.' });
      }
      const media = req.processedMedia?.[0];
      const msg = await Message.create({
        conversation: conv._id, sender: req.user._id, type,
        text: text?.trim(), media, replyTo, sharedPost,
        deliveredTo: conv.participants.filter(p => p.toString() !== req.user._id.toString()),
      });
      // Update conversation last message + unread counts
      const updates = { lastMessage: { text: text || (media ? '📷 Media' : ''), type, senderId: req.user._id, ts: new Date() } };
      conv.participants.forEach(pid => {
        if (pid.toString() !== req.user._id.toString()) {
          const key = `unreadCounts.${pid}`;
          updates[key] = (conv.unreadCounts?.get(pid.toString()) || 0) + 1;
        }
      });
      await Conversation.findByIdAndUpdate(conv._id, { $set: updates });
      const populated = await msg.populate('sender', 'username avatar verified');
      // Real-time emit
      const io = req.app.get('io');
      io.to(`conv:${conv._id}`).emit('new_message', { conversationId: conv._id, message: populated });
      conv.participants.forEach(pid => {
        if (pid.toString() !== req.user._id.toString()) {
          io.to(`user:${pid}`).emit('dm_notification', { conversationId: conv._id, from: { id: req.user._id, username: req.user.username, avatar: req.user.avatarUrl }, preview: text || '📷 Media', ts: Date.now() });
        }
      });
      res.status(201).json({ success: true, message: populated });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
  }
);

// ═══════════════════════════════════════════════════════════════
//  STORIES
// ═══════════════════════════════════════════════════════════════

// GET /api/stories/feed — stories from following
router_stories.get('/feed', protect, async (req, res) => {
  try {
    const me = await User.findById(req.user._id).select('following');
    const ids = [...(me.following || []), req.user._id];
    const stories = await Story.find({
      user: { $in: ids }, isDeleted: false,
      expiresAt: { $gt: new Date() },
    }).populate('user', 'username avatar verified').sort({ createdAt: -1 });
    // Group by user
    const grouped = {};
    stories.forEach(s => {
      const uid = s.user._id.toString();
      if (!grouped[uid]) grouped[uid] = { user: s.user, stories: [], hasUnread: false };
      const seen = s.viewers?.some(v => v.user?.toString() === req.user._id.toString());
      grouped[uid].stories.push({ ...s.toObject(), seen });
      if (!seen) grouped[uid].hasUnread = true;
    });
    res.json({ success: true, storyGroups: Object.values(grouped) });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// POST /api/stories — create story
router_stories.post('/', protect,
  upload.single('media'),
  handleStoryUpload,
  async (req, res) => {
    try {
      const { text, textStyle, music, location, audience } = req.body;
      if (!req.storyFilename) return res.status(400).json({ success: false, message: 'Media required.' });
      const story = await Story.create({
        user: req.user._id,
        media: { url: req.storyFilename, type: req.storyIsVideo ? 'video' : 'image' },
        text, textStyle: textStyle ? JSON.parse(textStyle) : undefined,
        music: music ? JSON.parse(music) : undefined,
        location, audience: audience || 'all',
      });
      await User.findByIdAndUpdate(req.user._id, { $inc: { storiesCount: 1 } });
      const populated = await story.populate('user', 'username avatar verified');
      // Notify followers
      const fullUser = await User.findById(req.user._id).select('followers');
      fullUser.followers.forEach(fid => {
        req.app.get('io').to(`user:${fid}`).emit('new_story', populated);
      });
      res.status(201).json({ success: true, story: populated });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
  }
);

// POST /api/stories/:id/view
router_stories.post('/:id/view', protect, async (req, res) => {
  try {
    const story = await Story.findById(req.params.id);
    if (!story) return res.status(404).json({ success: false, message: 'Story not found.' });
    const alreadyViewed = story.viewers?.some(v => v.user?.toString() === req.user._id.toString());
    if (!alreadyViewed) {
      story.viewers.push({ user: req.user._id, viewedAt: new Date() });
      story.viewersCount += 1;
      await story.save();
      req.app.get('io').to(`user:${story.user}`).emit('story_viewed', { storyId: story._id, viewedBy: { id: req.user._id, username: req.user.username, avatar: req.user.avatarUrl } });
    }
    res.json({ success: true });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ═══════════════════════════════════════════════════════════════
//  NOTIFICATIONS
// ═══════════════════════════════════════════════════════════════

router_notifs.get('/', protect, async (req, res) => {
  try {
    const { page = 1, limit = 30 } = req.query;
    const notifs = await Notification.find({ recipient: req.user._id })
      .populate('sender', 'username avatar verified')
      .populate('post', 'media')
      .sort({ createdAt: -1 }).skip((page-1)*limit).limit(+limit);
    const unreadCount = await Notification.countDocuments({ recipient: req.user._id, isRead: false });
    res.json({ success: true, notifications: notifs, unreadCount });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

router_notifs.put('/read-all', protect, async (req, res) => {
  try {
    await Notification.updateMany({ recipient: req.user._id, isRead: false }, { isRead: true, readAt: new Date() });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ═══════════════════════════════════════════════════════════════
//  SEARCH
// ═══════════════════════════════════════════════════════════════

router_search.get('/', optionalAuth, async (req, res) => {
  try {
    const { q, type = 'all', page = 1, limit = 20 } = req.query;
    if (!q?.trim()) return res.json({ success: true, users: [], posts: [], hashtags: [] });
    const results = {};
    if (type === 'all' || type === 'users') {
      results.users = await User.find({ $text: { $search: q }, isActive: true })
        .select('username fullName avatar verified bio followersCount').limit(10);
      results.users = results.users.map(u => ({ ...u.toObject(), avatar: u.avatarUrl }));
    }
    if (type === 'all' || type === 'posts') {
      results.posts = await Post.find({ $text: { $search: q }, isDeleted: false })
        .populate('user', 'username avatar verified')
        .sort({ engagementScore: -1 }).limit(+limit);
      results.posts = results.posts.map(p => ({ ...p.toObject(), media: p.mediaUrls }));
    }
    if (type === 'all' || type === 'hashtags') {
      results.hashtags = await Post.aggregate([
        { $match: { tags: { $regex: q, $options: 'i' } } },
        { $unwind: '$tags' },
        { $match: { tags: { $regex: q, $options: 'i' } } },
        { $group: { _id: '$tags', count: { $sum: 1 } } },
        { $sort: { count: -1 } }, { $limit: 10 },
        { $project: { tag: '$_id', count: 1, _id: 0 } },
      ]);
    }
    res.json({ success: true, ...results });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ═══════════════════════════════════════════════════════════════
//  EXPLORE (algorithm-ranked)
// ═══════════════════════════════════════════════════════════════

router_explore.get('/', optionalAuth, async (req, res) => {
  try {
    const { page = 1, limit = 30 } = req.query;
    const exclude = req.user ? (await User.findById(req.user._id).select('following')).following : [];
    const posts = await Post.find({
      user: req.user ? { $nin: [...exclude, req.user._id] } : {},
      isDeleted: false, expiresAt: { $exists: false },
      'media.0': { $exists: true },
    })
    .populate('user', 'username avatar verified')
    .sort({ engagementScore: -1, createdAt: -1 })
    .skip((page-1)*limit).limit(+limit);
    res.json({ success: true, posts: posts.map(p => ({ ...p.toObject(), media: p.mediaUrls })) });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ═══════════════════════════════════════════════════════════════
//  REELS
// ═══════════════════════════════════════════════════════════════

router_reels.get('/', optionalAuth, async (req, res) => {
  try {
    const { page = 1, limit = 10, cursor } = req.query;
    const query = { type: 'reel', isDeleted: false };
    if (cursor) query._id = { $lt: cursor };
    const reels = await Post.find(query)
      .populate('user', 'username fullName avatar verified bio followersCount')
      .sort({ createdAt: -1 }).limit(+limit);
    res.json({ success: true, reels: reels.map(r => ({ ...r.toObject(), media: r.mediaUrls, isLiked: req.user ? r.isLikedBy(req.user._id) : false })), nextCursor: reels[reels.length-1]?._id });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// POST /api/reels/:id/view
router_reels.post('/:id/view', optionalAuth, async (req, res) => {
  try {
    await Post.findByIdAndUpdate(req.params.id, { $inc: { viewsCount: 1 } });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ═══════════════════════════════════════════════════════════════
//  GROUPS
// ═══════════════════════════════════════════════════════════════

router_groups.get('/', optionalAuth, async (req, res) => {
  try {
    const { category, page = 1, limit = 12 } = req.query;
    const query = { isActive: true, privacy: { $ne: 'secret' } };
    if (category) query.category = category;
    const groups = await Group.find(query).populate('admin', 'username avatar').sort({ membersCount: -1 }).skip((page-1)*limit).limit(+limit);
    const result = groups.map(g => ({ ...g.toObject(), isMember: req.user ? g.members.some(m => m.toString() === req.user._id.toString()) : false }));
    res.json({ success: true, groups: result });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

router_groups.post('/:id/join', protect, async (req, res) => {
  try {
    const group = await Group.findById(req.params.id);
    if (!group) return res.status(404).json({ success: false, message: 'Group not found.' });
    const isMember = group.members.some(m => m.toString() === req.user._id.toString());
    if (isMember) {
      group.members.pull(req.user._id);
      group.membersCount = Math.max(0, group.membersCount - 1);
    } else {
      if (group.privacy === 'private') {
        group.pendingMembers.push(req.user._id);
        await group.save();
        return res.json({ success: true, status: 'pending', message: 'Join request sent.' });
      }
      group.members.push(req.user._id);
      group.membersCount += 1;
    }
    await group.save();
    res.json({ success: true, joined: !isMember, membersCount: group.membersCount });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

router_groups.post('/', protect, async (req, res) => {
  try {
    const { name, description, privacy, category } = req.body;
    const group = await Group.create({ name, description, privacy, category, admin: req.user._id, members: [req.user._id], membersCount: 1 });
    res.status(201).json({ success: true, group });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ── EXPORT all routers
module.exports = {
  userRoutes:   router_users,
  commentRoutes:router_comments,
  messageRoutes:router_messages,
  storyRoutes:  router_stories,
  notifRoutes:  router_notifs,
  searchRoutes: router_search,
  exploreRoutes:router_explore,
  reelRoutes:   router_reels,
  groupRoutes:  router_groups,
};
