module.exports = require('./allRoutes').reelsRoutes;
