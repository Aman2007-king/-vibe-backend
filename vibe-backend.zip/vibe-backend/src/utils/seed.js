// ============================================================
//  VIBE SOCIAL — DATABASE SEEDER
//  Run: node src/utils/seed.js
// ============================================================
require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');
const User     = require('../models/User');
const Post     = require('../models/Post');
const { Comment, Group, Story } = require('../models/index');

const MONGO_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/vibe_social';

const DEMO_USERS = [
  { username: 'alex.travels', fullName: 'Alex Johnson',   email: 'alex@vibe.app',  password: 'password123', bio: '📸 Photographer | 🌍 Explorer', verified: true,  followersCount: 12400 },
  { username: 'sara_art',     fullName: 'Sara Williams',  email: 'sara@vibe.app',  password: 'password123', bio: 'Artist & dreamer 🎨',         verified: false, followersCount: 8920  },
  { username: 'mike_lens',    fullName: 'Mike Chen',      email: 'mike@vibe.app',  password: 'password123', bio: 'Street photography 🏙️',       verified: true,  followersCount: 34100 },
  { username: 'luna_vibes',   fullName: 'Luna Reyes',     email: 'luna@vibe.app',  password: 'password123', bio: 'Living my best life ✨',      verified: false, followersCount: 21300 },
  { username: 'jay_fit',      fullName: 'Jay Kumar',      email: 'jay@vibe.app',   password: 'password123', bio: 'Fitness coach 💪',             verified: true,  followersCount: 45600 },
  { username: 'nadia_eats',   fullName: 'Nadia Patel',    email: 'nadia@vibe.app', password: 'password123', bio: 'Food blogger 🍜 | Mumbai',    verified: false, followersCount: 18700 },
  { username: 'demo',         fullName: 'Demo User',      email: 'demo@vibe.app',  password: 'demo',        bio: 'Testing Vibe! 👋',            verified: false, followersCount: 0     },
];

const CAPTIONS = [
  'Golden hour never gets old 🌅 #photography #nature #travel',
  'Exploring hidden gems ✈️ Where to next? Drop a 📍 below! #adventure',
  'This view is unreal 😍 Pinch me I must be dreaming #wanderlust',
  'Weekend energy 🎉 Living for moments like these! #vibes',
  'Slow down and appreciate the beauty around you ✨ #mindfulness #peace',
  'New adventures, new memories 🌏 #travel #explore #journey',
  'Making memories that last forever 💫 #grateful #blessed',
  'Life is too short for boring days 🌈 #lifestyle #happy',
  'Chasing sunsets and good vibes 🌅 #sunset #photography',
  'The world is yours to explore 🗺️ #backpacking #adventure',
];

const LOCATIONS = ['Paris, France 🗼','Tokyo, Japan 🏯','New York, USA 🗽','Bali, Indonesia 🌺','London, UK 🎡','Sydney, Australia 🦘','Dubai, UAE 🌆','Mumbai, India 🌊'];

const DEMO_GROUPS = [
  { name: 'Photography Lovers', description: 'A community for photography enthusiasts worldwide.', privacy: 'public', category: 'Photography', membersCount: 124000 },
  { name: 'Travel & Adventure',  description: 'Share your travel stories and tips.',               privacy: 'public', category: 'Travel',      membersCount: 89000  },
  { name: 'Foodies United',      description: 'For people who live to eat.',                       privacy: 'public', category: 'Food',        membersCount: 210000 },
  { name: 'Fitness & Wellness',  description: 'Health, fitness and wellness community.',           privacy: 'private',category: 'Fitness',     membersCount: 67000  },
  { name: 'Art & Design',        description: 'Creative minds sharing art and design.',             privacy: 'public', category: 'Art',         membersCount: 45000  },
  { name: 'Tech Talks',          description: 'Latest in technology and innovation.',               privacy: 'public', category: 'Technology',  membersCount: 33000  },
];

const DEMO_IMAGE_URLS = [
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=600',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=600',
  'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=600',
  'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=600',
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=600',
  'https://images.unsplash.com/photo-1543610892-0b1f7e6d8ac1?w=600',
  'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=600',
];

async function seed() {
  try {
    await mongoose.connect(MONGO_URI);
    console.log('✅ Connected to MongoDB');

    // Clear existing data
    await Promise.all([User.deleteMany(), Post.deleteMany(), Comment.deleteMany(), Group.deleteMany(), Story.deleteMany()]);
    console.log('🗑️  Cleared existing data');

    // Create users
    const hashedUsers = await Promise.all(DEMO_USERS.map(async u => ({
      ...u,
      password: await bcrypt.hash(u.password, 12),
      avatar: DEMO_IMAGE_URLS[DEMO_USERS.indexOf(u) % DEMO_IMAGE_URLS.length],
      postsCount: Math.floor(Math.random() * 200) + 50,
    })));
    const users = await User.insertMany(hashedUsers);
    console.log(`👥 Created ${users.length} users`);

    // Set up follow relationships
    for (let i = 0; i < users.length - 1; i++) {
      for (let j = i + 1; j < users.length; j++) {
        if (Math.random() > 0.3) {
          users[i].following.push(users[j]._id);
          users[j].followers.push(users[i]._id);
          users[i].followingCount += 1;
          users[j].followersCount += 1;
        }
      }
    }
    await Promise.all(users.map(u => u.save({ validateBeforeSave: false })));
    console.log('🤝 Set up follow relationships');

    // Create posts
    const posts = [];
    for (let i = 0; i < 40; i++) {
      const user = users[i % (users.length - 1)]; // exclude demo user
      const isReel = Math.random() > 0.65;
      const mediaUrl = DEMO_IMAGE_URLS[i % DEMO_IMAGE_URLS.length];
      posts.push({
        user: user._id,
        type: isReel ? 'reel' : 'post',
        media: [{ url: mediaUrl, type: 'image', width: 600, height: 600 }],
        caption: CAPTIONS[i % CAPTIONS.length],
        location: LOCATIONS[i % LOCATIONS.length],
        tags: ['#vibe', '#photography', '#travel'].slice(0, Math.floor(Math.random() * 3) + 1),
        likes: users.slice(0, Math.floor(Math.random() * users.length)).map(u => u._id),
        likesCount: Math.floor(Math.random() * 3000) + 100,
        commentsCount: Math.floor(Math.random() * 200) + 5,
        savesCount: Math.floor(Math.random() * 500),
        viewsCount: isReel ? Math.floor(Math.random() * 100000) + 1000 : 0,
        engagementScore: Math.floor(Math.random() * 5000) + 100,
        audio: isReel ? { title: 'Original Audio', artist: user.username } : undefined,
        createdAt: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
      });
    }
    const savedPosts = await Post.insertMany(posts);
    console.log(`📸 Created ${savedPosts.length} posts`);

    // Add comments to posts
    const comments = [];
    const commentTexts = ['Amazing! 😍','Love this! ❤️','So beautiful 🔥','Goals! ✨','Wow incredible!','This is fire 🔥','Stunning! 📸','💯💯💯','Obsessed with this!','Need to visit!'];
    for (const post of savedPosts.slice(0, 20)) {
      const numComments = Math.floor(Math.random() * 5) + 2;
      for (let j = 0; j < numComments; j++) {
        comments.push({
          post: post._id, user: users[j % users.length]._id,
          text: commentTexts[Math.floor(Math.random() * commentTexts.length)],
          likesCount: Math.floor(Math.random() * 50),
          createdAt: new Date(post.createdAt.getTime() + Math.random() * 3600000),
        });
      }
    }
    await Comment.insertMany(comments);
    console.log(`💬 Created ${comments.length} comments`);

    // Create groups
    const adminUser = users[0];
    const groupDocs = DEMO_GROUPS.map(g => ({
      ...g, admin: adminUser._id,
      members: users.slice(0, Math.floor(Math.random() * 4) + 2).map(u => u._id),
    }));
    await Group.insertMany(groupDocs);
    console.log(`👥 Created ${groupDocs.length} groups`);

    console.log('\n🎉 Seed complete!');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('Test accounts:');
    console.log('  Username: demo      | Password: demo');
    console.log('  Username: alex.travels | Password: password123');
    console.log('  Username: sara_art  | Password: password123');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    process.exit(0);
  } catch (err) {
    console.error('❌ Seed error:', err);
    process.exit(1);
  }
}

seed();
