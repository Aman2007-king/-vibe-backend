// ============================================================
//  VIBE SOCIAL — SOCKET.IO REAL-TIME ENGINE
//  Handles: Live feed, DMs, notifications, stories, typing,
//           online presence, reactions, live likes/comments
// ============================================================

const jwt  = require('jsonwebtoken');
const User = require('../models/User');

// Maps for tracking live state
const onlineUsers  = new Map(); // userId → Set of socketIds
const typingTimers = new Map(); // roomId:userId → timer

function initSocket(io) {

  // ── Auth Middleware ────────────────────────────────────────
  io.use(async (socket, next) => {
    try {
      const token =
        socket.handshake.auth?.token ||
        socket.handshake.headers?.authorization?.replace('Bearer ', '');
      if (!token) return next(new Error('Authentication required'));
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const user = await User.findById(decoded.id).select('-password');
      if (!user) return next(new Error('User not found'));
      socket.user = user;
      next();
    } catch (err) {
      next(new Error('Invalid token'));
    }
  });

  io.on('connection', (socket) => {
    const userId = socket.user._id.toString();
    console.log(`🟢 ${socket.user.username} connected [${socket.id}]`);

    // ── Track Online Presence ──────────────────────────────
    if (!onlineUsers.has(userId)) onlineUsers.set(userId, new Set());
    onlineUsers.get(userId).add(socket.id);

    // Join user's personal room (for DMs & notifications)
    socket.join(`user:${userId}`);

    // Notify followers this user is online
    notifyFollowersOnline(io, socket.user, true);

    // Broadcast updated online count
    io.emit('online_count', onlineUsers.size);

    // ── FEED ──────────────────────────────────────────────
    // When someone posts — broadcast to followers
    socket.on('new_post', async (data) => {
      try {
        const followers = socket.user.followers || [];
        followers.forEach(followerId => {
          io.to(`user:${followerId}`).emit('feed_new_post', {
            post: data.post,
            fromUser: { id: userId, username: socket.user.username, avatar: socket.user.avatar },
          });
        });
        // Also broadcast to explore feed globally
        socket.broadcast.emit('explore_new_post', data.post);
      } catch (e) { console.error('new_post error:', e); }
    });

    // ── LIKES (real-time counter sync) ──────────────────
    socket.on('post_like', (data) => {
      // Broadcast like to everyone watching this post
      io.emit('post_like_update', {
        postId: data.postId,
        likesCount: data.likesCount,
        liked: data.liked,
        byUser: { id: userId, username: socket.user.username },
      });
      // Notify post owner
      if (data.postOwnerId && data.postOwnerId !== userId) {
        io.to(`user:${data.postOwnerId}`).emit('notification', {
          type: 'like',
          fromUser: { id: userId, username: socket.user.username, avatar: socket.user.avatar },
          postId: data.postId,
          postThumb: data.postThumb,
          message: `${socket.user.username} liked your photo`,
          ts: Date.now(),
        });
      }
    });

    // ── COMMENTS (real-time) ────────────────────────────
    socket.on('new_comment', (data) => {
      io.emit('comment_added', {
        postId: data.postId,
        comment: {
          ...data.comment,
          user: { id: userId, username: socket.user.username, avatar: socket.user.avatar },
          ts: Date.now(),
        },
      });
      if (data.postOwnerId && data.postOwnerId !== userId) {
        io.to(`user:${data.postOwnerId}`).emit('notification', {
          type: 'comment',
          fromUser: { id: userId, username: socket.user.username, avatar: socket.user.avatar },
          postId: data.postId,
          postThumb: data.postThumb,
          message: `${socket.user.username} commented: "${data.comment.text.slice(0, 40)}"`,
          ts: Date.now(),
        });
      }
    });

    // ── STORIES ──────────────────────────────────────────
    socket.on('story_view', (data) => {
      io.to(`user:${data.storyOwnerId}`).emit('story_viewed', {
        storyId: data.storyId,
        viewedBy: { id: userId, username: socket.user.username, avatar: socket.user.avatar },
        ts: Date.now(),
      });
    });
    socket.on('story_react', (data) => {
      io.to(`user:${data.storyOwnerId}`).emit('story_reaction', {
        storyId: data.storyId,
        emoji: data.emoji,
        from: { id: userId, username: socket.user.username, avatar: socket.user.avatar },
      });
    });

    // ── DIRECT MESSAGES ──────────────────────────────────
    socket.on('join_conversation', (conversationId) => {
      socket.join(`conv:${conversationId}`);
    });
    socket.on('leave_conversation', (conversationId) => {
      socket.leave(`conv:${conversationId}`);
    });

    socket.on('send_message', (data) => {
      const msgPayload = {
        ...data.message,
        senderId: userId,
        senderUsername: socket.user.username,
        senderAvatar: socket.user.avatar,
        ts: Date.now(),
        status: 'delivered',
      };
      // Send to entire conversation room
      io.to(`conv:${data.conversationId}`).emit('new_message', {
        conversationId: data.conversationId,
        message: msgPayload,
      });
      // Send notification to recipient if not in room
      if (data.recipientId) {
        io.to(`user:${data.recipientId}`).emit('dm_notification', {
          conversationId: data.conversationId,
          from: { id: userId, username: socket.user.username, avatar: socket.user.avatar },
          preview: data.message.text ? data.message.text.slice(0, 50) : '📷 Photo',
          ts: Date.now(),
        });
      }
    });

    socket.on('message_seen', (data) => {
      io.to(`conv:${data.conversationId}`).emit('messages_read', {
        conversationId: data.conversationId,
        readBy: userId,
        readAt: Date.now(),
      });
    });

    socket.on('message_reaction', (data) => {
      io.to(`conv:${data.conversationId}`).emit('message_reacted', {
        messageId: data.messageId,
        emoji: data.emoji,
        by: { id: userId, username: socket.user.username },
      });
    });

    // ── TYPING INDICATORS ────────────────────────────────
    socket.on('typing_start', (data) => {
      socket.to(`conv:${data.conversationId}`).emit('user_typing', {
        conversationId: data.conversationId,
        user: { id: userId, username: socket.user.username },
        isTyping: true,
      });
      // Auto-stop after 5s
      const key = `${data.conversationId}:${userId}`;
      clearTimeout(typingTimers.get(key));
      typingTimers.set(key, setTimeout(() => {
        socket.to(`conv:${data.conversationId}`).emit('user_typing', {
          conversationId: data.conversationId,
          user: { id: userId, username: socket.user.username },
          isTyping: false,
        });
      }, 5000));
    });
    socket.on('typing_stop', (data) => {
      const key = `${data.conversationId}:${userId}`;
      clearTimeout(typingTimers.get(key));
      socket.to(`conv:${data.conversationId}`).emit('user_typing', {
        conversationId: data.conversationId,
        user: { id: userId, username: socket.user.username },
        isTyping: false,
      });
    });

    // ── FOLLOW / UNFOLLOW ────────────────────────────────
    socket.on('follow_user', (data) => {
      io.to(`user:${data.targetUserId}`).emit('new_follower', {
        from: { id: userId, username: socket.user.username, avatar: socket.user.avatar },
        ts: Date.now(),
      });
      io.to(`user:${data.targetUserId}`).emit('notification', {
        type: 'follow',
        fromUser: { id: userId, username: socket.user.username, avatar: socket.user.avatar },
        message: `${socket.user.username} started following you`,
        ts: Date.now(),
      });
    });

    // ── LIVE VIDEO / REELS ───────────────────────────────
    socket.on('go_live', (data) => {
      socket.broadcast.emit('user_went_live', {
        user: { id: userId, username: socket.user.username, avatar: socket.user.avatar },
        roomId: data.roomId,
        ts: Date.now(),
      });
      // Notify followers
      (socket.user.followers || []).forEach(fid => {
        io.to(`user:${fid}`).emit('notification', {
          type: 'live',
          fromUser: { id: userId, username: socket.user.username, avatar: socket.user.avatar },
          message: `${socket.user.username} is now live!`,
          ts: Date.now(),
        });
      });
    });

    // ── POST SAVE ────────────────────────────────────────
    socket.on('post_save', (data) => {
      io.emit('post_save_update', {
        postId: data.postId,
        savesCount: data.savesCount,
        savedBy: userId,
      });
    });

    // ── REELS EVENTS ─────────────────────────────────────
    socket.on('reel_share', (data) => {
      socket.broadcast.emit('reel_shared', {
        reelId: data.reelId,
        sharedBy: { id: userId, username: socket.user.username },
        sharesCount: data.sharesCount,
      });
    });

    // ── DISCONNECT ────────────────────────────────────────
    socket.on('disconnect', () => {
      console.log(`🔴 ${socket.user.username} disconnected [${socket.id}]`);
      const sockets = onlineUsers.get(userId);
      if (sockets) {
        sockets.delete(socket.id);
        if (sockets.size === 0) {
          onlineUsers.delete(userId);
          notifyFollowersOnline(io, socket.user, false);
          // Update last seen in DB (non-blocking)
          User.findByIdAndUpdate(userId, { lastSeen: new Date() }).catch(() => {});
        }
      }
      io.emit('online_count', onlineUsers.size);
    });
  });

  console.log('📡 Socket.io real-time engine initialized');
}

async function notifyFollowersOnline(io, user, isOnline) {
  const followers = user.followers || [];
  followers.forEach(fid => {
    io.to(`user:${fid}`).emit('friend_online_status', {
      userId: user._id.toString(),
      username: user.username,
      isOnline,
      lastSeen: isOnline ? null : new Date(),
    });
  });
}

function getOnlineUsers() { return onlineUsers; }
function isUserOnline(userId) { return onlineUsers.has(userId.toString()); }

module.exports = { initSocket, getOnlineUsers, isUserOnline };
